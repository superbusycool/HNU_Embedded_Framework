/**
  ******************************************************************************
  * @file           : config_uart.c\h
  * @brief          : 
  * @note           : 
  ******************************************************************************
  */
	
#include "config_uart.h"



void USART1_rxDataHandler(uint8_t *rxBuf)
{
}


void USART2_rxDataHandler(uint8_t *rxBuf)
{
}

void USART3_rxDataHandler(uint8_t *rxBuf)
{
}

/**
 * @brief ����ϵͳ����
 * 
 * @param rxBuf 
 */
void USART4_rxDataHandler(uint8_t *rxBuf)
{
  
}

void USART5_rxDataHandler(uint8_t *rxBuf)
{
}
void USART6_rxDataHandler(uint8_t *rxBuf)
{

}
